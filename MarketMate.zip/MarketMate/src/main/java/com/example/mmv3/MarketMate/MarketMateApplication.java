package com.example.mmv3.MarketMate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarketMateApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarketMateApplication.class, args);
	}

}
